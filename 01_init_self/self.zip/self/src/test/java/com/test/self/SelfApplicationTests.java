package com.test.self;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelfApplicationTests {

	@Test
	void contextLoads() {
	}

}
