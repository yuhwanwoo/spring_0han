package bittest.bit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitApplication.class, args);
	}

}
